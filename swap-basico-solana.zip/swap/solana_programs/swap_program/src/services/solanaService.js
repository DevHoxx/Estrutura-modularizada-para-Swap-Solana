import { Connection, PublicKey } from '@solana/web3.js';
import { Token, TOKEN_PROGRAM_ID } from '@solana/spl-token';

const connection = new Connection('https://api.mainnet-beta.solana.com');

export const solanaService = {
  getTokenList: async () => {
    const response = await fetch('https://token-list.solana.com/tokens');
    return await response.json();
  },

  getTokenBalance: async (tokenSymbol, publicKey) => {
    try {
      const tokenInfo = this.tokenList.find(t => t.symbol === tokenSymbol);
      if (!tokenInfo) return 0;

      const tokenAddress = new PublicKey(tokenInfo.address);
      const tokenAccount = await Token.getAssociatedTokenAddress(
        TOKEN_PROGRAM_ID,
        tokenAddress,
        publicKey
      );

      const balance = await connection.getTokenAccountBalance(tokenAccount);
      return balance.value.uiAmount || 0;
    } catch (error) {
      console.error('Error fetching balance:', error);
      return 0;
    }
  },

  performSwap: async ({ inputToken, outputToken, amount, wallet }) => {
    // Implemente a lógica real de swap aqui
    // Use protocolos como Raydium, Orca ou Serum
  }
};