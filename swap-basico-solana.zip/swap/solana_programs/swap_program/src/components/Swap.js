import { useState, useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { solanaService } from '../services/solanaService';
import styles from '../styles/Swap.module.css';

const Swap = () => {
  const { publicKey } = useWallet();
  const [inputToken, setInputToken] = useState('SOL');
  const [outputToken, setOutputToken] = useState('USDC');
  const [inputAmount, setInputAmount] = useState('');
  const [outputAmount, setOutputAmount] = useState('');
  const [balance, setBalance] = useState(0);
  const [tokenList, setTokenList] = useState([]);

  useEffect(() => {
    const fetchTokens = async () => {
      const tokens = await solanaService.getTokenList();
      setTokenList(tokens);
    };
    fetchTokens();
  }, []);

  useEffect(() => {
    if (publicKey) {
      const fetchBalance = async () => {
        const balance = await solanaService.getTokenBalance(inputToken, publicKey);
        setBalance(balance);
      };
      fetchBalance();
    }
  }, [publicKey, inputToken]);

  const handleSwap = async () => {
    if (!inputAmount || parseFloat(inputAmount) <= 0) return;

    try {
      await solanaService.performSwap({
        inputToken,
        outputToken,
        amount: inputAmount,
        wallet: publicKey,
      });
    } catch (error) {
      console.error('Swap error:', error);
    }
  };

  return (
    <div className={styles.swapContainer}>
      {/* ... (mantenha a estrutura do JSX anterior) */}
    </div>
  );
};

export default Swap;