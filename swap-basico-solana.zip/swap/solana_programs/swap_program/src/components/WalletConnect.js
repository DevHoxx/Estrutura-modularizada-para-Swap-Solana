import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import styles from '../styles/Swap.module.css';

const WalletConnect = () => {
  const { publicKey } = useWallet();

  return (
    <div className={styles.walletContainer}>
      {publicKey ? (
        <div className={styles.connectedWallet}>
          Conectado: {publicKey.toBase58()}
        </div>
      ) : (
        <WalletMultiButton className={styles.walletButton}>
          Conectar Carteira
        </WalletMultiButton>
      )}
    </div>
  );
};

export default WalletConnect;